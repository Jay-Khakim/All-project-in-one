<!-- Product -->
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!-- Product -->

<?php
  $image = "";
  if(count($product->images)>0){
    $image = $product->images[0]['img'];
  }else{
    $image = 'product_2.jpg';
  }
?>
<div class="product">
  <div class="product_image"><img src="images/<?php echo e($image); ?>" alt="<?php echo e($product->title); ?>"></div>
  <div class="product_extra product_new"><a href="<?php echo e(route('showCategory', $product->category['alias'])); ?>"><?php echo e($product->category['title']); ?></a></div>
  <div class="product_content">
    <div class="product_title"><a href="<?php echo e(route('showProduct',['category', $product->id])); ?>"><?php echo e($product->title); ?></a></div>
    <?php if($product->new_price != null): ?>
      <div class="" style="text-decoration: line-through; color: red;">$<?php echo e($product->price); ?>

      </div>
      <div class="product_price">$<?php echo e($product->new_price); ?></div>
    <?php else: ?>
      <div class="product_price">$<?php echo e($product->price); ?></div>
    <?php endif; ?>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /opt/lampp/htdocs/myfolder/laravel2/resources/views/ajax/order-by.blade.php ENDPATH**/ ?>