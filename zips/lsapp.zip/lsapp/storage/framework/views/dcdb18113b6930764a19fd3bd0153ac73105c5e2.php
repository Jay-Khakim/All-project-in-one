 
 <?php $__env->startSection('title'); ?>
     Main
 <?php $__env->stopSection(); ?>

 <?php $__env->startSection('content'); ?>
    <div class="jumbotron text-center">
        <h1><?php echo e($title); ?> </h1>
        <p>This is a laravel lesson</p>
        <p><a class="btn btn-outline-primary btn-lg" href="<?php echo e(route('login')); ?>" role="button">Login</a>
        <a class="btn btn-outline-success btn-lg" href="<?php echo e(route('register')); ?>" role="button">Register</a></p>
     <div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/myfolder/lsapp/resources/views/pages/index.blade.php ENDPATH**/ ?>