<?php $__env->startSection('content'); ?>
    <a href="/posts" class="btn btn-outline-secondary">Go Back</a>
    <br>
    <br>
    <h1><?php echo e($post->title); ?></h1>
    <img style="width: 100%;" src="/storage/cover_images/<?php echo e($post->cover_image); ?>" alt="">
    <br>
    <br>
    <br>
    <div>
        <?php echo e($post->body); ?>

    </div>
    <hr> 
    <small>Written on <?php echo e($post->created_at); ?> by <strong><?php echo e($post->user->name); ?> </small>
    <hr>
    <?php if(!Auth::guest()): ?>
        <?php if(Auth::user()->id == $post->user_id): ?>
            <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-outline-primary">Edit</a>
            <?php echo Form::open(['action'=> ['PostsController@destroy', $post->id], 'method'=>'Post', 'class'=>'pull-right']); ?>

                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                <?php echo e(Form::submit('Delete', ['class'=>'btn btn-outline-danger'])); ?>

            <?php echo Form::close(); ?>

        <?php endif; ?>
    
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/myfolder/lsapp/resources/views/posts/show.blade.php ENDPATH**/ ?>