 
 <?php $__env->startSection('title'); ?>
     About
 <?php $__env->stopSection(); ?>

 <?php $__env->startSection('content'); ?>
     <div class="jumbotron text-center">
        <h1>About Page</h1>
     </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/myfolder/lsapp/resources/views/pages/about.blade.php ENDPATH**/ ?>