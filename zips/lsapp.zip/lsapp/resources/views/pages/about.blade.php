 @extends('layouts.app')
 @section('title')
     About
 @endsection

 @section('content')
     <div class="jumbotron text-center">
        <h1>About Page</h1>
     </div>
 @endsection