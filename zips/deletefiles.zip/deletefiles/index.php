<!-- Deleting one or multiple files in the same time! -->


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form class="" action="deletefile.php" method="post">
      <input type="text" name="filename" placeholder="Seperate each name with comma (,)" style="width: 300px;" value="">
      <button type="submit" name="submit">Delete files</button>
    </form>
  </body>
</html>
