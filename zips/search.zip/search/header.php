<?php
include "mysqli_connect.php";
 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style.css">
  </head>
  <body style="background-color: #f3f3f3; font-family: arial;">
