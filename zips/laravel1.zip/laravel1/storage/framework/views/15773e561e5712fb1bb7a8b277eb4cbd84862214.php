<?php $__env->startSection('title-block'); ?>Contacts <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <h1>Contacts page</h1>


  <form  action="<?php echo e(route('contact-form')); ?>" method="post">

    <?php echo csrf_field(); ?>
    <div class="form-group">
      <label for="name">Name: </label>
      <input type="text" class="form-control" name="name" placeholder="Name" id="name" value="<?php if (isset($_POST['name'])) echo htmlspecialchars($_POST['name'], ENT_QUOTES); ?>">
    </div>

    <div class="form-group">
      <label for="email">E-mail: </label>
      <input type="email" class="form-control" name="email" placeholder="E-mail" id="email" value="<?php if (isset($_POST['email'])) echo htmlspecialchars($_POST['email'], ENT_QUOTES); ?>">
    </div>

    <div class="form-group">
      <label for="subject">Subject: </label>
      <input type="text" class="form-control" name="subject" placeholder="Subject" id="subject" value="<?php if (isset($_POST['subject'])) echo htmlspecialchars($_POST['subject'], ENT_QUOTES); ?>">
    </div>

    <div class="form-group">
      <label for="message">Message: </label>
      <textarea name="message" id="message" placeholder="Write your message" class="form-control" rows="2" cols="30"></textarea>

      <button type="submit"  class=" btn btn-success">Send</button>
    </div>

  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/myfolder/laravel/resources/views/contact.blade.php ENDPATH**/ ?>