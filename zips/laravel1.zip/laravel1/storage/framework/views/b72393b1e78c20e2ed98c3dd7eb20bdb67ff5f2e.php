<?php $__env->startSection('aside'); ?>
<div class="aside">
  <h4>Side panel!</h4>
  <p>This is a simple side panel</p>
  <?php echo $__env->yieldSection(); ?>
</div>
<?php /**PATH /opt/lampp/htdocs/myfolder/laravel/resources/views/inc/aside.blade.php ENDPATH**/ ?>