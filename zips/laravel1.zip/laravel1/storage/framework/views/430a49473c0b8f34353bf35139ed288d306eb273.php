<?php $__env->startSection('title-block'); ?><?php echo e($data->subject); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <h1><?php echo e($data->subject); ?></h1>
  <div class="alert alert-info">
    <p> <strong><?php echo e($data->message); ?></strong> </p>
    <p><?php echo e($data->email); ?></p>
    <p> <small><?php echo e($data->created_at); ?></small> </p>
    <a href="<?php echo e(route('contact-update', $data->id)); ?>"> <button type="button" class="btn btn-primary" name="button">Edit</button> </a>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/myfolder/laravel/resources/views/one-message.blade.php ENDPATH**/ ?>