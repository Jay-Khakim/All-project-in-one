@section('aside')
<div class="aside">
  <h4>Side panel!</h4>
  <p>This is a simple side panel</p>
  @show
</div>
